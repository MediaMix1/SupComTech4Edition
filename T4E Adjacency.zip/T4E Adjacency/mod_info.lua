name = "SupCom T4 Edition - Muh Adjacency!"
uid = "bce32d24-1119-4747-b42c-6df19573209f"
version = 1
copyright = "Copyleft"
description = "One mod of many for the Supreme Commander: Tech 4 Project!"
author = "MediaMix1"
icon = "/mods/T4E Adjacency/icon.png"
selectable = true
exclusive = false
ui_only = false
conflicts = {
}