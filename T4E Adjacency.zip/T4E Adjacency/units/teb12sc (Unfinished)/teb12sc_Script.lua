local TEnergyStorageUnit = import('/lua/terranunits.lua').TEnergyStorageUnit
local AdjacencyBuffs = import('/mods/T4E Adjacency/hook/lua/sim/AdjacencyBuffs.lua')

teb12sc = Class(TEnergyStorageUnit) {
}
TypeClass = teb12sc