local CMassFabricationUnit = import('/lua/cybranunits.lua').CMassFabricationUnit
local AdjacencyBuffs = import('/mods/T4E Adjacency/hook/lua/sim/AdjacencyBuffs.lua')

trb02ws = Class(CMassFabricationUnit) {
}
TypeClass = trb02ws