local TMassFabricationUnit = import('/lua/terranunits.lua').TMassFabricationUnit
local AdjacencyBuffs = import('/mods/T4E Adjacency/hook/lua/sim/AdjacencyBuffs.lua')

teb02ws = Class(TMassFabricationUnit) {
}
TypeClass = teb02ws