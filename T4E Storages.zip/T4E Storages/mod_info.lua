name = "SupCom T4 Edition - Storage Plus"
uid = "65251b6e-7494-461d-8bac-61bb83bb9429"
version = 1.0
description = "One mod of many for the Supreme Commander: Tech 4 Project!"
author = "MediaMix1 + Balthazar"
icon = "/mods/T4E Storages/icon.png"
