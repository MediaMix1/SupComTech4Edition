	-- Aeon Storages
	Description['tab12es'] = "Many years after the Seraphim Invasion, the Aeon Illuminate sought a more efficient way of storing their Energy. Their most successful idea, funnily enough, came from someone who simply split the original design into two smaller pieces."
	Description['tab12ms'] = "Created by Grand Sculptor Balthazar, these larger Mass Storages offer a higher Mass production bonus and allow their commanders to accumulate larger amounts of Mass with minimal risk."
	Description['tab13es'] = "It was originally intended to have a somewhat symmetrical design, but Aeon schematic designers made a mistake while replicating their design - but the design stuck due to function over form."
	Description['tab13ms'] = "Another creation by Grand Sculptor Balthazar, these seemingly gargantuan Mass Storages offer an immense mass production bonus, but are surprisingly volatile compared to their smaller counterparts."
	-- UEF Storages
	Description['teb12es'] = "Who said bigger ain't better? Especially since these larger Energy Storages don't blow up so badly!"
	Description['teb12ms'] = "Although arguably indistinguishable from their smaller counterparts, in terms of design, these larger Mass Storages offer minimal risk and higher rewards."
	Description['teb13es'] = "These gargantuan batteries offer a LOT of energy storage and yield a very high Energy Production bonus, but they also blow up pretty badly - albeit simply pretty."
	Description['teb13ms'] = "Oh, I get it! The notches on the square show its tech level! Totally unique!"
	-- Cybran Storages
	Description['trb12es'] = "Kitbashed by Cybran engineers, the AA Duo Cells offer a substantially larger bonus in energy production and Energy Storage, all without the risk of volatility."
	Description['trb12ms'] = "Why build more T1 Storages when you can just slap them together and call it a T2 Storage?"
	Description['trb13es'] = "The AAA Quadro Cells are absolutely massive and can store loads of Energy, but engineers had trouble finding ways to mitigate its volatilty like they were able to with the Duo Cells."
	Description['trb13ms'] = "These goliathan mass storages offer a hefty bonus in mass production for adjacent Extractors and Fabricators, but their size makes it rather difficult to Shield them effectively."
	-- Seraphim Storages
	Description['tsb12es'] = "|TRANSLATED TO ENGLISH| The humans found a way to create larger storages for their Energy and Mass. Don't tell the others, but I think they also found out how we managed to make our own without making them absurdly volatile."
	Description['tsb12ms'] = "|TRANSLATED TO ENGLISH| Our Medium Mass Storages don't have any notably unique design features, but at least it works as intended."
	Description['tsb13es'] = "|TRANSLATED TO ENGLISH| We've had to cut costs regarding our Giant Storages, sadly - not because we cannot afford to make these things NOT explode very dangerously, but rather because we didn't want to risk humans humans stealing our ideas again."
	Description['tsb13ms'] = "|TRANSLATED TO ENGLISH| As awesome as these Giant Mass Storages may be, try not to rely too much on them! Your economy might get tanked pretty hard if you cause a Chain Reaction due to enemy artillery and the like!"