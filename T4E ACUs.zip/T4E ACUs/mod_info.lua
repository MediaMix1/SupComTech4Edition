name = "SupCom T4 Edition - ACU Add-On"
uid = "ff40668c-b770-4a59-a5e6-619768aa51ee"
version = 1.0
description = "One mod of many for the Supreme Commander: Tech 4 Project!"
author = "MediaMix1"
icon = "/mods/T4E ACUs/icon.png"
