local CLandFactoryUnit = import('/lua/cybranunits.lua').CLandFactoryUnit

trb04lg = Class(CLandFactoryUnit) {}

TypeClass = trb04lg