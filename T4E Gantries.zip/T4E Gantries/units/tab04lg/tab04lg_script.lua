local ALandFactoryUnit = import('/lua/aeonunits.lua').ALandFactoryUnit

tab04lg = Class(ALandFactoryUnit) {}

TypeClass = tab04lg