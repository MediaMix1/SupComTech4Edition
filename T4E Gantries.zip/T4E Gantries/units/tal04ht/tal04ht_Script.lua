local ALandUnit = import('/lua/aeonunits.lua').ALandUnit
local ADFCannonOblivionWeapon = import('/lua/aeonweapons.lua').ADFCannonOblivionWeapon
local ADFDisruptorCannonWeapon = import('/lua/aeonweapons.lua').ADFDisruptorCannonWeapon

tal04ht = Class(ALandUnit) {

    Weapons = {
        MainGun = Class(ADFCannonOblivionWeapon) {},
		Anti_Shield_Gun = Class(ADFDisruptorCannonWeapon) {},
    },
}
TypeClass = tal04ht