local ASeaFactoryUnit = import('/lua/aeonunits.lua').ASeaFactoryUnit
tab04ng = Class(ASeaFactoryUnit) {    
    OnCreate = function(self)
        ASeaFactoryUnit.OnCreate(self)
        self.BuildPointSlider = CreateSlider(self, self:GetBlueprint().Display.BuildAttachBone or 0, -15, 0, 0, -1)
        self.Trash:Add(self.BuildPointSlider)
    end,
}

TypeClass = tab04ng

