local AAirFactoryUnit = import('/lua/aeonunits.lua').AAirFactoryUnit
tab04ag = Class(AAirFactoryUnit) {}

TypeClass = tab04ag
