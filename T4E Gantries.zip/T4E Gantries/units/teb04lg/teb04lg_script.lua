local TLandFactoryUnit = import('/lua/terranunits.lua').TLandFactoryUnit

teb04lg = Class(TLandFactoryUnit) {}

TypeClass = teb04lg