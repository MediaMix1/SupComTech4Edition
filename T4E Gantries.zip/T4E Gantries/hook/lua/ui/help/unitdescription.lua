	--Aeon Gantries
	Description['tab04ag'] = "The Aeon Illuminate is well known for their powerful, refined aircraft. This is especially present in their Cumulonimbus Sky Gantries - whose design is merely an upscaled version of their lower tech cousins."
	Description['tab04lg'] = "Kitbashed together by an inexperienced architect, the Aeon's Megapalaces are surprisingly capable of quickly churning out large armies of higher tech units - including the supoort of their legendary Galactic Colossi."
	Description['tab04ng'] = "For those special days out at the beach!"