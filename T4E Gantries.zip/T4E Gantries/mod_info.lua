name = "SupCom T4 Edition - Gantries!"
uid = "dfcdc9cd-2b5f-4cf8-83f0-3739b384db10"
version = 1.0
description = "One mod of many for the Supreme Commander: Tech 4 Project!"
author = "MediaMix1"
icon = "/mods/T4E Gantries/icon.png"
