name = "SupCom T4 Edition - Resource Generators"
uid = "aab27450-4f2f-4fe8-88ea-59bdbda9df15"
version = 11
copyright = "Copyleft"
description = "One mod of many for the Supreme Commander: Tech 4 Project!"
author = "MediaMix1 + MadMax"
icon = "/mods/T4E Paragons/icon.png"
selectable = true
exclusive = false
ui_only = false
conflicts = {
	"ac99e8dd-3c45-46a3-bbe6-0d840575a87c", --v1.0
}