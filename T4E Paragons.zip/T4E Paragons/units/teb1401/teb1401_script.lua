local AStructureUnit = import('/lua/aeonunits.lua').AStructureUnit
local FxAmbient = import('/lua/effecttemplates.lua').AResourceGenAmbient
local DeathNukeWeapon = import('/lua/sim/defaultweapons.lua').DeathNukeWeapon

local CreateAeonParagonBuildingEffects = import("/lua/effectutilities.lua").CreateAeonParagonBuildingEffects

teb1401 = Class(AStructureUnit) {

    Weapons = {
        DeathWeapon = Class(DeathNukeWeapon) {},
    },

    StartBeingBuiltEffects = function(self, builder, layer)
        AStructureUnit.StartBeingBuiltEffects(self, builder, layer)
        CreateAeonParagonBuildingEffects(self)
    end,

    OnStopBeingBuilt = function(self, builder, layer)
        AStructureUnit.OnStopBeingBuilt(self, builder, layer)
        ChangeState(self, self.ResourceOn)
        self:ForkThread(self.ResourceMonitor)

        for k, v in FxAmbient do
            CreateAttachedEmitter(self, 'Orb', self.Army, v)
        end
    end,

    ResourceOn = State {
        Main = function(self)
            local aiBrain = self:GetAIBrain()
            local massAdd = 0
            local energyAdd = 0
            local maxMass = self:GetBlueprint().Economy.MaxMass
            local maxEnergy = self:GetBlueprint().Economy.MaxEnergy

            while true do
                local massNeed = aiBrain:GetEconomyRequested('MASS') * 10
                local energyNeed = aiBrain:GetEconomyRequested('ENERGY') * 10

                local massIncome = (aiBrain:GetEconomyIncome('MASS') * 10) - massAdd
                local energyIncome = (aiBrain:GetEconomyIncome('ENERGY') * 10) - energyAdd

                massAdd = 20
                if massNeed - massIncome > 0 then
                    massAdd = massAdd + massNeed - massIncome
                end

                if maxMass and massAdd > maxMass then
                   massAdd = maxMass
                end
                self:SetProductionPerSecondMass(massAdd)

                energyAdd = 1000
                if energyNeed - energyIncome > 0 then
                    energyAdd = energyAdd + energyNeed - energyIncome
                end
                if maxEnergy and energyAdd > maxEnergy then
                    energyAdd = maxEnergy
                end
                self:SetProductionPerSecondEnergy(energyAdd)

                WaitSeconds(.5)
            end
        end,
    },

    GetRandomDir = function(self)
        local num = Random(0, 2)
        if num > 1 then
            return 1
        end
        return -1
    end,
}

TypeClass = teb1401